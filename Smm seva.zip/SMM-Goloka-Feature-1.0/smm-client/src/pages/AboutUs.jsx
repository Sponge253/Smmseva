import React from "react";
import AboutUsMain from "../components/AboutUs/AboutUsMain";


const AboutUs = () => {
  return (
    <div>
        <AboutUsMain/>
    </div>
  );
};

export default AboutUs;
