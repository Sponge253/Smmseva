import React from "react";
import Service from "../components/Services/Service";
import ServiceSection from "../components/Services/ServiceSection";

const ServicesPage = () => {
  return (
    <div>
      <Service />
      <ServiceSection />
    </div>
  );
};

export default ServicesPage;
