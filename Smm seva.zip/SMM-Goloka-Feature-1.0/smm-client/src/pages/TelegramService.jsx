import React from "react";
import TelegramServiceMain from "../components/TelegramService/TelegramServiceMain";
import EngagementCardsGrid from "../components/TelegramService/EngagementCard";

const TelegramService = () => {
  return (
    <div>
      <TelegramServiceMain />
    </div>
  );
};

export default TelegramService;
