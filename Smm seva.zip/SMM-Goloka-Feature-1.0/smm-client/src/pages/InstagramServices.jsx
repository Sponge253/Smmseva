import React from "react";
import Section1 from "../components/InstagramService/Section1";
import CardsSection from "../components/Homepage/CardsSection";
import FeatureSection from "../components/Homepage/FeatureSection";
import FAQs from "../components/Homepage/FAQs";
import CustomerTestimonials from "../components/Homepage/customerTestimonials";

const InstagramServices = () => {
  return (
    <div>
      <Section1 />
      <CardsSection />
      <div style={{ margin: "150px 0 100px 0" }}>
        {" "}
        <FeatureSection />
      </div>
      <FAQs />
      <div style={{ margin: "80px" }}>
        <CustomerTestimonials />
      </div>
    </div>
  );
};

export default InstagramServices;
