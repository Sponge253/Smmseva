import React from "react";
import "../assets/styles/register.css";
import { Link } from "react-router-dom";

const Login = () => {
  const spanArray = Array.from({ length: 50 }, (_, i) => i);

  return (
    <>
      <div className="register-container">
        <div className="reg-container">
          <div className="login-box">
            <h2>Login</h2>
            <form action="#">
              <div className="input-box">
                <input type="email" required />
                <label>Email</label>
              </div>
              <div className="input-box">
                <input type="password" required />
                <label>Password</label>
              </div>
              <div className="forgot-pass">
                <a href="#">Forgot your password?</a>
              </div>
              <button type="submit" className="reg-btn">
                Submit
              </button>
              <div className="signup-link">
                Don't have an account?{" "}
                <Link id="link" to="/register">
                  Signup
                </Link>
              </div>
            </form>
          </div>
          {/* Dynamically render spans */}
          {spanArray.map((i) => (
            <span key={i} style={{ "--i": i }}></span>
          ))}
        </div>
      </div>
    </>
  );
};

export default Login;
