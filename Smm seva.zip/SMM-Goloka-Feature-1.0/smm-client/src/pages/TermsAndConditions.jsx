import React from "react";
import { BsArrowUp } from "react-icons/bs";
import "../assets/styles/terms.css";

const TermsAndConditions = () => {
  return (
    <>
      <div className="main-class">
        <div className="content-class">
          <h2 style={{ textAlign: "center", color: "#00eeff" }}>
            <b>TERMS AND CONDITIONS OF USE</b>
          </h2>
          <p style={{ textAlign: "center" }}>
            Thanks for using our services. The services are being provided by{" "}
            <a href="http://www.smmSeva.com" style={{ color: "#00eeff" }}>
              SMM Seva MMC
            </a>
            , +1 (605) 982-2520. By accessing this website, you are agreeing to
            be bound by these website Terms and Conditions of Use, all
            applicable laws and regulations, and agree that you are responsible
            for compliance with any applicable local laws.
          </p>

          <h2>
            <b>Use License</b>
          </h2>
          <p className="text-to-left">
            Permission is granted to temporarily download one copy of the
            materials (information or software) on smmSeva's website for
            personal, non-commercial transitory viewing only. This is the grant
            of a license, not a transfer of title, and under this license, you
            may not:
          </p>
          <ul>
            <li>Modify or copy the materials.</li>
            <li>
              Use the materials for any commercial purpose or public display.
            </li>
            <li>
              Attempt to decompile or reverse engineer any software contained on
              SmmSeva's website.
            </li>
            <li>
              Remove any copyright or other proprietary notations from the
              materials.
            </li>
            <li>
              Transfer the materials to another person or "mirror" the materials
              on any other server.
            </li>
          </ul>
          <p>
            This license shall automatically terminate if you violate any of
            these restrictions and may be terminated by SmmSeva's at any time.
            Upon terminating your viewing of these materials or upon the
            termination of this license, you must destroy any downloaded
            materials in your possession whether in electronic or printed
            format.
          </p>

          <h2>
            <b>Disclaimer</b>
          </h2>
          <p>
            The materials on SmmSeva's web site are provided “as is”. SMM Seva
            makes no warranties, expressed or implied, and hereby disclaims and
            negates all other warranties, including without limitation, implied
            warranties or conditions of merchantability, fitness for a
            particular purpose, or non-infringement of intellectual property or
            other violation of rights. Further, SMM Seva does not warrant or
            make any representations concerning the accuracy, likely results, or
            reliability of the use of the materials on its Internet web site or
            otherwise relating to such materials or on any sites linked to this
            site.
          </p>

          <h2>
            <b>Limitations</b>
          </h2>
          <p>
            In no event shall SMM Seva or its suppliers be liable for any
            damages (including, without limitation, damages for loss of data or
            profit, or due to business interruption,) arising out of the use or
            inability to use the materials on
            <a href="http://www.smmSeva.com" style={{ color: "#00eeff" }}>
              SMM Seva LLC &nbsp;
            </a>
            Internet site, even if SMM Seva or a SMM Seva's authorized
            representative has been notified orally or in writing of the
            possibility of such damage. Because some jurisdictions do not allow
            limitations on implied warranties, or limitations of liability for
            consequential or incidental damages, these limitations may not apply
            to you.
          </p>
          <h2>
            <b>Revisions and Errata :</b>
          </h2>
          <p>
            The materials appearing on SMM Seva's web site could include
            technical, typographical, or photographic errors. SMM Seva does not
            warrant that any of the materials on its web site are accurate,
            complete, or current. SMM Seva may make changes to the materials
            contained on its web site at any time without notice. SMM Seva does
            not, however, make any commitment to update the materials.
          </p>

          <h2>
            <b>Billing</b>
          </h2>
          <p>
            Payments on SMM Seva are processed using either
            Paytm,Coinbase,Coinpayments and other manual methods with secure
            system with no sensitive financial information being input through
            our web site. Secure method of accepting payments is processed using
            SSL encryption. By purchasing our services you are explicitly
            agreeing that you clearly understand and agree to what you are
            purchasing and will not file a fraudulent dispute via PayTM, UPI or
            any third party payment gateway. Furthermore, Adding funds in
            <a href="http://www.smmSeva.com" style={{ color: "#00eeff" }}>
              SMM Seva LLC &nbsp;
            </a>
            must be from your personal account only and you agree to not add
            funds from any third party who is not using our site or your user
            profile, If you do not agree or make an make an payment through an
            third party we have the right to suspend your account and ban your
            IP address and take strict legal action upon Section 415 and Section
            498A. Upon a fraudulent attempt to file a dispute or chargeback, we
            receive the right, if necessary, to reset all followers and likes,
            terminate your account and/or permanently ban your IP address. Users
            acknowledge chargebacks, disputes, or payment reversals
          </p>
          <h2>
            <b>Site terms of USe Modifications:</b>
          </h2>
          <p>
            SMM Seva may revise these terms of use for its web site at any time
            without notice. By using this web site you are agreeing to be bound
            by the then current version of these Terms and Conditions of Use. We
            hereby, also receive the right to change/disable any site content
            with notice.
          </p>
          <h2>
            <b>Guarantee of Services</b>
          </h2>
          <p>
            We do not guarantee you to provide an refill or an refund on any
            service / order. Service title / Description is just an display with
            estimation. Refills on any order are being provided according to the
            start and end count of an order which is displayed on
            www.smmSeva.com/orders page. If the order is below end count we can
            add it for an refill and if the order is above end count. If the
            start count differs from the existing count, the guarantee is not
            supported and you cannot claim an guarantee. We don't guarantee any
            time for refilling any order neither we guarantee the refill
            delivery.
          </p>

          <h2>
            <b>Refund Policy</b>
          </h2>
          <p>
            We do not provide any refunds to the source of payment. Once you
            deposit a balance on
            <a href="http://www.smmSeva.com" style={{ color: "#00eeff" }}>
              SMM Seva LLC &nbsp;
            </a>
            internet site, there is no way to reverse it. You agree that once
            you complete a payment, you will not file a dispute or a chargeback
            against us for any reason. If you file a dispute or charge-back
            against us after a deposit, we reserve the right to terminate all
            future orders, ban you from our site. We also reserve the right to
            take away any followers or likes we delivered to your or your
            clients Instagram/Facebook/Twitter or other social media account.
            Orders placed in SMM Seva will not be refunded or canceled after
            they are placed. You will receive a refund credit to your SMM Seva
            account if the order is non deliverable. Misplaced or Private
            account orders will not qualify for a refund. Be sure to confirm
            each and every order before placing it.
          </p>

          <h2>
            <b>Orders</b>
          </h2>
          <p>
            Placing multiple orders at same time will result in status as mark
            complete, we can't refund any orders and users cannot claim any
            refunds on those orders too. Orders on wrong/expired links are not
            eligible for an refund. We don't guarantee any delivery time on any
            orders, all content on
            <a href="http://www.smmSeva.com" style={{ color: "#00eeff" }}>
              http://www.smmSeva.com &nbsp;
            </a>
            are based on an estimation. We don't guarantee/take responsibility
            on any issue with your social media accounts, you have the full
            responsibility with dealing to the terms & conditions of all social
            media sites. We don't recommend to use our services for commercial
            purposes, our services are provided to users who are willing to
            increase there followers, likes and views for entertainment
            purposes. Our Services must be used in non-commercial purpose and on
            your own social media accounts only. You don't reserve any right or
            regulations for selling these services to third party for earning.
            You must not misuse our services with respect of any
            community/social/political purposes. You cannot cheat and use our
            services for fraudulent purposes, if you do so we'll permanently ban
            your IP Address and Account from our site. In case of any fraudulent
            activites, we can also provide your personal information to the
            Government Authorities.
            <br /> <br />
            You will only use the SMM Seva website in a manner which follows all
            agreements made with Instagram/Facebook/Youtube social media site on
            their individual Terms of Service page. SMM Seva rates are subject
            to change at any time without notice. The payment/refund policy
            stays in effect in the case of rate changes. SMM Seva does not
            guarantee a delivery time for any services. We offer our best
            estimation for when the order will be delivered. This is only an
            estimation and SMM Seva will not refund orders that are processing
            if you feel they are taking too long. SMM Seva tries hard to deliver
            exactly what is expected from us by our re-sellers. In this case, we
            reserve the right to change a service type if we deem it necessary
            to complete an
          </p>

          <h2>
            <b>Services</b>
          </h2>
          <p>
            SMM Seva will only be used to promote your
            Instagram/Twitter/Facebook or Social account and help boost your
            "Appearance" only. We DO NOT guarantee your new followers will
            interact with you, we simply guarantee you to get the followers you
            pay for. We DO NOT guarantee 100% of our accounts will have a
            profile picture, full bio and uploaded pictures, although we strive
            to make this the reality for all accounts. You will not upload
            anything into the SMM Seva site including nudity or any material
            that is not accepted or suitable for the Instagram/Twitter/Facebook
            or Social Media community. Private accounts would not get a refund!
            Please ensure that your account is public before ordering.
          </p>

          <h2>
            <b>Privacy Policy</b>
          </h2>
          <p>
            This policy covers how we use your personal information. We take
            your privacy seriously and will take all measures to protect your
            personal information. Any personal information received will only be
            used to fill your order. We will not sell or redistribute your
            personal information to anyone. All personal information is
            encrypted and saved in secure servers.
          </p>
        </div>
      </div>

      {/* Go to top button */}
    </>
  );
};

export default TermsAndConditions;
