import React from "react";
import IntroContainer from "../components/PlansPage/IntroContainer";
import OrderForm from "../components/PlansPage/OrderForm";
import PlansContainer from "../components/PlansPage/PlansContainer";

const PlansPage = () => {
  return (
    <div>
      <IntroContainer />
      <div className="main-plans-container d-flex justify-content-center align-items-start gap-4">
        <OrderForm />
        <PlansContainer />
      </div>
    </div>
  );
};

export default PlansPage;
