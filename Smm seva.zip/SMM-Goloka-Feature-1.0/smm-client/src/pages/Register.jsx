import React from "react";
import "../assets/styles/register.css";
import { Form, Link } from "react-router-dom";
import RegisterForm from "../components/Register/RegisterForm";
import DiscoverBenefits from "../components/Register/DiscoverBenefits";
import WhyChoose from "../components/Homepage/WhyChoose";

const Register = () => {
  return (
    <>
      <RegisterForm />
      <DiscoverBenefits />
      <WhyChoose />
    </>
  );
};

export default Register;
