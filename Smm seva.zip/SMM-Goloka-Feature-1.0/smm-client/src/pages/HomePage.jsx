import React from "react";
import CardsSection from "../components/Homepage/CardsSection";
import SignInSection from "../components/Homepage/SignInSection";
import InfiniteScroller from "../components/Homepage/InfiniteScroller";
import WhyChoose from "../components/Homepage/WhyChoose";
import SectionTemplate from "../components/Homepage/WhatSection";
import CarouselSection from "../components/Homepage/CarouselSection";
import BlockSection from "../components/Homepage/BlockSection";
import FeatureSection from "../components/Homepage/FeatureSection";
import FAQs from "../components/Homepage/FAQs";
import CustomerTestimonials from "../components/Homepage/customerTestimonials";
import ComparisonTable from "../components/Homepage/ComparisonTable";
import BrandsCarousel from "../components/Homepage/BrandsCarousel";
import AchievementSection from "../components/Homepage/AchievementSection";
import CharitySection from "../components/Homepage/CharitySection";
import Blogs from "../components/Homepage/Blogs";

const HomePage = () => {
  return (
    <div>
      <SignInSection />

      <InfiniteScroller />

      <SectionTemplate />
      <BlockSection />
      <CardsSection />
      <CarouselSection />
      <FeatureSection />

      <ComparisonTable />
      <CharitySection />
      <CustomerTestimonials />
      <AchievementSection />
      <BrandsCarousel />
      <FAQs />
      <Blogs />
    </div>
  );
};

export default HomePage;
