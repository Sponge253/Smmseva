import React from "react";
import "../../assets/styles/register.css";
import { Form, Link } from "react-router-dom";

const RegisterForm = () => {
  return (
    <div className="register-container">
      <div className="reg-container">
        <div className="login-box">
          <h2>
            Hey Signup on <span style={{ color: "#00eeff" }}>SMMSeva</span>
          </h2>
          <form action="#">
            <div className="input-box">
              <input type="text" required />
              <label>Name</label>
            </div>
            <div className="input-box">
              <input type="tel" required />
              <label>Mobile</label>
            </div>
            <div className="input-box">
              <input type="email" required />
              <label>Email</label>
            </div>
            <div className="input-box">
              <input type="password" required />
              <label>Password</label>
            </div>
            <div
              className="step-content"
              style={{
                width: "100%",
                marginBottom: "20px",
                background:
                  "linear-gradient( 135deg,rgba(0, 0, 0, 0.8),rgba(34, 34, 34, 0.6))",
              }}
            >
              <h4>Have a Referral Code?</h4>
              <div className="input-box">
                <input
                  type="text"
                  style={{ border: "1px solid #fff" }}
                  required
                />
                <label>Enter Code</label>
              </div>
            </div>
            <div class="form-check form-switch mb-2">
              <input
                className="form-check-input"
                type="checkbox"
                role="switch"
                id="flexSwitchCheckDefault"
              />
              <label
                style={{ color: "#fff" }}
                className="form-check-label"
                for="flexSwitchCheckDefault"
              >
                I have read and agreed with{" "}
                <Link
                  style={{ color: "#00eeff", textDecoration: "underLine" }}
                  to={"/"}
                >
                  Terms of Service
                </Link>
              </label>
            </div>
            <button type="submit" className="reg-btn">
              Submit
            </button>
            <div className="signup-link">
              Already have an account?{" "}
              <Link id="link" to="/login">
                Login
              </Link>
            </div>
          </form>
        </div>
      </div>
      <div className="process-container">
        <h1 className="text-center">
          Our <span style={{ color: "#00eeff" }}>Signup</span> Process
        </h1>
        <p className="text-center">
          Streamlined Registration Made Simple: Follow the Below Steps and Join
          Us Effortlessly!
        </p>
        <div>
          <div className="step-container">
            <div className="step-number">01</div>
            <div className="step-content">
              <h4>Fill Your Info</h4>
              <p>Fill in the form all your relevant details.</p>
            </div>
          </div>
          <div className="step-container">
            <div className="step-number">02</div>
            <div className="step-content">
              <h4>Verify Your Email</h4>
              <p>You will receive an verification email.</p>
            </div>
          </div>
          <div className="step-container">
            <div className="step-number">03</div>
            <div className="step-content">
              <h4>Start ordering</h4>
              <p>After Verification you would start ordering.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterForm;
