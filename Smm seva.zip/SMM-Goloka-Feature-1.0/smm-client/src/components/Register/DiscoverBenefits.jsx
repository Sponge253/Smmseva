import React from "react";

const DiscoverBenefits = () => {
  return (
    <div className="discover-container">
      <h3>Discover the Benefits of Using the Best SMM Panel!</h3>
      <div className="discover-item-container">
        <div className="discover-item">13394499+ Orders Completed</div>
        <div className="discover-item">24/7 Customer Support</div>
        <div className="discover-item">Multiple payment methods</div>
        <div className="discover-item">9.9/10 satisfaction</div>
        <div className="discover-item">Distributor panel</div>
        <div className="discover-item">
          1644 high-quality and affordable services
        </div>
        <div className="discover-item">+200K happy customers</div>
        <div className="discover-item">Reference system</div>
      </div>
    </div>
  );
};

export default DiscoverBenefits;
