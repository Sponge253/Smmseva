import React, { useState } from 'react';
import { AiOutlinePlusCircle, AiOutlineWallet } from 'react-icons/ai'; // For Orders and Payments
import { FaTasks, FaTelegramPlane, FaWhatsapp } from 'react-icons/fa'; // For Mass Orders and Contact
import { MdMiscellaneousServices, MdOutlineSupportAgent } from 'react-icons/md'; // For Services, Refunds, and Support
import { BsBoxSeam } from 'react-icons/bs'; // For Track Orders
import { IoIosArrowForward } from 'react-icons/io'; // For submenu arrows
import '../assets/styles/sidePanel.css';
import helpingOne from '../assets/images/helpingOne.jpg';
// import { MdRefund } from 'react-icons/md'; // Correct icon
import { AiOutlineDollarCircle } from 'react-icons/ai';
import { RiRefund2Line } from 'react-icons/ri'; // Refund icon from Remix Icons





const SidePanel = () => {
  const [openSubMenu, setOpenSubMenu] = useState(null);

  const toggleSubMenu = (menu) => {
    setOpenSubMenu((prevMenu) => (prevMenu === menu ? null : menu));
  };

  return (
    <div className="side-panel">
      <div className="profile-section">
        <img src={helpingOne} alt="Profile" className="profile-pic" />
        <span className="username">SMM Sevak</span>
        <span className="balance">₹71.3925655</span>
      </div>
      <nav className="menu">
        <p>Place Orders</p>
        <ul>
          <li>
            <div onClick={() => toggleSubMenu("newOrder")}>
              <AiOutlinePlusCircle size={20} /> <a href="#new-order">New Order</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "newOrder" && (
              <ul className="submenu">
                <li>Option 1</li>
                <li>Option 2</li>
                <li>Option 3</li>
              </ul>
            )}
          </li>
          <li>
            <div onClick={() => toggleSubMenu("massOrders")}>
              <FaTasks size={20} /> <a href="#mass-orders">Mass Orders</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "massOrders" && (
              <ul className="submenu">
                <li>Option 1</li>
                <li>Option 2</li>
                <li>Option 3</li>
              </ul>
            )}
          </li>
          <li>
            <div onClick={() => toggleSubMenu("services")}>
              <MdMiscellaneousServices size={20} /> <a href="#services">Services</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "services" && (
              <ul className="submenu">
                <li><a href='/instagram-services'>Instagram Services</a></li>
                <li><a href='/telegram-services'>Telegram Services</a></li>
                <li><a href='/services'>Other Services</a></li>
              </ul>
            )}
          </li>
        </ul>
        <p>Payments</p>
        <ul>
          <li>
            <div onClick={() => toggleSubMenu("addFunds")}>
              <AiOutlineWallet size={20} /> <a href="#add-funds">Add Funds</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "addFunds" && (
              <ul className="submenu">
                <li>Option 1</li>
                <li>Option 2</li>
                <li>Option 3</li>
              </ul>
            )}
          </li>
        </ul>
        <p>Order History</p>
        <ul>
          <li>
            <div onClick={() => toggleSubMenu("trackOrders")}>
              <BsBoxSeam size={20} /> <a href="#track-orders">Track Orders</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "trackOrders" && (
              <ul className="submenu">
                <li>Option 1</li>
                <li>Option 2</li>
                <li>Option 3</li>
              </ul>
            )}
          </li>
          <li>
            <div onClick={() => toggleSubMenu("refunds")}>
            <AiOutlineDollarCircle size={20} /> <a href="#refunds">Refunds</a>
              <IoIosArrowForward />
            </div>
            {openSubMenu === "refunds" && (
              <ul className="submenu">
                <li>Option 1</li>
                <li>Option 2</li>
                <li>Option 3</li>
              </ul>
            )}
          </li>
        </ul>
      </nav>
      <div className="contact-us">
        <a href="#support" className="contact-item">
          <MdOutlineSupportAgent size={20} /> Support
        </a>
        <a href="#telegram" className="contact-item">
          <FaTelegramPlane size={20} /> Telegram
        </a>
        <a href="#whatsapp" className="contact-item">
          <FaWhatsapp size={20} /> WhatsApp
        </a>
      </div>
    </div>
  );
};

export default SidePanel;

