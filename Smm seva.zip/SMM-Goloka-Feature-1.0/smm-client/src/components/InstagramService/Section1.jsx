import React from "react";
import "../../assets/styles/InstagramService/section1.css";
import img from "../../assets/images/AIfhovO.png";
import img2 from "../../assets/images/RtwE82p.png";

const Section1 = () => {
  return (
    <div className="section1-main">
      <div className="section-title">
        <h3>
          Boost your social presence with the best
          <span className="highlight"> Instagram followers panel</span>
        </h3>
        <p>
          Discover the best SMM panel for Instagram. Gain real followers quickly
          and enhance your engagement. Start boosting your profile today!
        </p>
      </div>
      <div className="image-section">
        <div className="d-flex flex-column justify-content-start align-items-start">
          <h3>Unveil the Secrets of Instagram Followers Panel!</h3>
          <p>
            Enter the realm of the most trusted website to boost your engagement
            through uplifted Instagram followers now!
          </p>
        </div>
        <img src={img} />
      </div>
      <div className="image-section">
        <img src={img2} />
        <div className="d-flex flex-column gap-2 justify-content-start align-items-start">
          <h3>The Cheapest SMM Panel Instagram is Waiting for You!</h3>
          <p>
            Showcase yourself on the best social media platform and increase
            your followers instantly through the best SMM Panel Instagram.
            Connect with us today!
          </p>
        </div>
      </div>
      <div className="section-title">
        <h3>
          <span className="highlight">Benefits </span>of Using SMM Panel
          Instagram
        </h3>
        <p>
          If you’ve discovered us, nobody can stop you from gaining popularity
          on the most prominent social media sites. <br />
          Let’s explore some advantages of using the top SMM Panel Instagram.
        </p>
      </div>
      <div className="section1-buttons">
        <button>Increased number of followers</button>
        <button>Higher audience engagement</button>
        <button>Excellent visibility</button>
        <button>Time-saving</button>
        <button>Enhanced reach, and much more</button>
      </div>
      <p className="text-center " style={{ marginBottom: "100px" }}>
        So, what are you waiting for? Connect with us and get the superb
        services of SMM panel Instagram for Indian followers at affordable
        prices.
      </p>
    </div>
  );
};

export default Section1;
