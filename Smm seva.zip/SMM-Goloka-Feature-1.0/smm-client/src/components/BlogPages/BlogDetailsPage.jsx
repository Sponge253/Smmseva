import React from "react";
import { useLocation } from "react-router-dom";
import "../../assets/styles/BlogPage/BlogDetailsPage.css"

const BlogDetailsPage = () => {
  const location = useLocation();
  const { blog } = location.state;

  return (
    <div className="blog-details">
      <h1>{blog.title}</h1>
      <img src={blog.image} alt={blog.title} />
      <p>{blog.description}</p>
    </div>
  );
};

export default BlogDetailsPage;