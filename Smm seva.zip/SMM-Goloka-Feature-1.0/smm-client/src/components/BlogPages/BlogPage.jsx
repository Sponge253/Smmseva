import React from 'react';
import "../../assets/styles/BlogPage/BlogPage.css";
import { IoIosArrowRoundForward } from "react-icons/io";
import { Link } from "react-router-dom";

const BlogPage = () => {
    const mainBlog = {
        id: 0,
        title: "What is SMM? How it Works",
        description:
            "Social Media Marketing (SMM) refers to the use of social media platforms to promote a product, service, or brand...",
        image: "https://cdn.mypanel.link/7de874/kzjia4k8nygbrwij.jpg",
    };

    const subBlogs = [
        {
            id: 4,
            title: "Why Content is King in SMM",
            description:
                "Discover the importance of high-quality content in driving successful social media campaigns...",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_-hmELxuJht444QN3rIDTrFWLyPjTdWJzIw&s",
        },
        {
            id: 5,
            title: "How to Measure SMM Success",
            description:
                "Learn about the key metrics to track the performance of your social media marketing efforts...",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgkCqugz8CPGPfjuzfn760kGWc6tKG46PUog&s",
        },
        {
            id: 6,
            title: "Building Engagement with Interactive Posts",
            description:
                "Explore strategies to increase engagement using interactive content on social media...",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUGOr_yWyT9PF9TQlpvNAkfycRIuIjYBZiFA&s",
        },
        {
            id: 7,
            title: "The Benefits of Paid SMM Campaigns",
            description:
                "Find out how paid advertising on social media can help you target specific demographics effectively...",
            image: "https://img.freepik.com/premium-vector/smm-social-media-marketing-concept-advertising-business-internet-through-social-network-like-share-content_277904-11097.jpg?w=2000",
        },
        {
            id: 8,
            title: "SMM vs. Traditional Marketing: A Comparison",
            description:
                "Understand the key differences and advantages of social media marketing over traditional methods...",
            image: "https://autonomenp.com/wp-content/uploads/2022/05/How-SMM-works-768x340.jpg",
        },
        {
            id: 9,
            title: "How Social Media Algorithms Work",
            description:
                "Dive deep into how algorithms on social platforms decide what content users see...",
            image: "https://cdn.mypanel.link/7de874/7qkitgxjie5uehbi.png",
        },
    ];

    return (
        <div style={{ marginBottom: "80px" }}>
            <h1 className="text-center">
                Check Out <span style={{ color: "#00eeff" }}>Our Blogs</span>
            </h1>
            <div className="blogs-section">
                {/* Main Blog */}
                <Link to={`/blogPage/${mainBlog.id}`} state={{ blog: mainBlog }} className="main-blog">
                    <img src={mainBlog.image} alt={mainBlog.title} />
                    <h5>{mainBlog.title}</h5>
                    <p>{mainBlog.description}</p>
                </Link>

                {/* Sub Blogs */}
                <div>
                    {subBlogs.map((blog, index) => (
                        <Link
                            key={index}
                            to={`/blogPage/${blog.id}`}
                            state={{ blog }}
                            className="sub-blog"
                        >
                            <img src={blog.image} alt={blog.title} />
                            <div>
                                <h5>{blog.title}</h5>
                                <p>{blog.description}</p>
                            </div>
                        </Link>
                    ))}
                </div>
            </div>

            {/* Blogs Button */}
            {/* <div className="blogs-btn d-flex justify-content-center">
        <button>
          Check all blogs <IoIosArrowRoundForward size={20} />
        </button>
      </div> */}
        </div>
    );
};

export default BlogPage;