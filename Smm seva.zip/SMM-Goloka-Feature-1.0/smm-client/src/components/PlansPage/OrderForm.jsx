import React from "react";
import { HiMagnifyingGlass } from "react-icons/hi2";

const OrderForm = () => {
  return (
    <div className="order-form">
      <form>
        <div className="search d-flex ">
          <input placeholder="Search" type="text" />
          <button>
            <HiMagnifyingGlass />
          </button>
        </div>
        <div class="input-group mb-3">
          <select class="form-select" id="inputGroupSelect02">
            <option selected>Choose Category</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
        <div class="input-group mb-3">
          <select class="form-select" id="inputGroupSelect02">
            <option selected>Choose Service</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
        <textarea placeholder="Description" />
        <input type="text" placeholder="Link" />

        <input type="text" placeholder="Quantity" />
        <input type="text" placeholder="Average Time" />
        <input type="text" placeholder="Charge" />
        <button className="place-order-button">Place Order</button>
      </form>
    </div>
  );
};

export default OrderForm;
