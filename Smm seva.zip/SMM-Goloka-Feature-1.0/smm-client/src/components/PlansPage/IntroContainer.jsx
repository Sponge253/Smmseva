import React from "react";
import "../../assets/styles/plans.css";
import { FaWhatsapp } from "react-icons/fa";

const IntroContainer = () => {
  return (
    <div className="intro-container">
      <div>
        <h3>Empowering Your Social Media Growth!</h3>
        <p>
          Your trusted SMM panel for fast, reliable, and affordable social media
          services. Join influencers, brands, and agencies worldwide in boosting
          engagement and achieving real growth with our top-quality solutions.
        </p>

        <button>
          Join Our Community{" "}
          <FaWhatsapp size={40} style={{ color: "#25D366" }} />
        </button>
      </div>
      <img
        src="https://cdn.mypanel.link/7gc9nb/mei9t36tp6wecw0f.png"
        alt="SMM Services"
      />
    </div>
  );
};

export default IntroContainer;
