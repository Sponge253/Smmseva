import React, { useState } from "react";

import fb from "../../assets/images/fb.png";
import insta from "../../assets/images/insta.png";
import yt from "../../assets/images/yt.png";
import linkedin from "../../assets/images/in.png";

const logos = [fb, insta, yt, linkedin, fb, insta, yt, linkedin, fb];

const dummyServices = [
  {
    id: 1871,
    name: "Instagram Auto Reel/IGTV Views [40k-50k/hr]",
    price: "$0.039",
    oldPrice: "$0.026",
  },
  {
    id: 1872,
    name: "YouTube Video Views [100k/hr]",
    price: "$0.059",
    oldPrice: "$0.049",
  },
  {
    id: 1873,
    name: "Facebook Page Likes [10k/hr]",
    price: "$0.019",
    oldPrice: "$0.015",
  },
  {
    id: 1874,
    name: "LinkedIn Post Engagements [20k/hr]",
    price: "$0.045",
    oldPrice: "$0.040",
  },
  {
    id: 1875,
    name: "Instagram Follower Boost [5k/hr]",
    price: "$0.050",
    oldPrice: "$0.045",
  },
  {
    id: 1874,
    name: "LinkedIn Post Engagements [20k/hr]",
    price: "$0.045",
    oldPrice: "$0.040",
  },
  {
    id: 1875,
    name: "Instagram Follower Boost [5k/hr]",
    price: "$0.050",
    oldPrice: "$0.045",
  },
  {
    id: 1875,
    name: "Instagram Follower Boost [5k/hr]",
    price: "$0.050",
    oldPrice: "$0.045",
  },
  {
    id: 1874,
    name: "LinkedIn Post Engagements [20k/hr]",
    price: "$0.045",
    oldPrice: "$0.040",
  },
  {
    id: 1875,
    name: "Instagram Follower Boost [5k/hr]",
    price: "$0.050",
    oldPrice: "$0.045",
  },
  {
    id: 1874,
    name: "LinkedIn Post Engagements [20k/hr]",
    price: "$0.045",
    oldPrice: "$0.040",
  },
];

const PlansContainer = () => {
  const [activeLogo, setActiveLogo] = useState(1);

  const handleLogoClick = (index) => {
    setActiveLogo(index);
  };

  return (
    <div className="plans-form">
      <div className="logos-container">
        <div className="service-logos">
          {logos.map((logo, i) => (
            <div
              key={i}
              className={`logo-item ${activeLogo === i ? "active-logo" : ""}`}
              onClick={() => handleLogoClick(i)}
            >
              <img src={logo} alt={`logo-${i}`} />
            </div>
          ))}
        </div>
      </div>
      <div className="services-items">
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Service Name</th>
                <th>Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {dummyServices.map((service) => (
                <tr key={service.id}>
                  <td>{service.id}</td>
                  <td>{service.name}</td>
                  <td>
                    <span
                      style={{ color: "grey", textDecoration: "line-through" }}
                    >
                      {service.oldPrice}
                    </span>{" "}
                    {service.price}
                  </td>
                  <td>
                    <button>Buy Now</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PlansContainer;
