import React from "react";
import "../../assets/styles/Services/service.css";
import trendyReach from "../../assets/images/trendyReach.png";
import instagram from "../../assets/images/instagram.png";
import bestThreads from "../../assets/images/bestThreads.png";
import spotify from "../../assets/images/spotify.png";
import x from "../../assets/images/X (1).png";
import ServiceSection from "./ServiceSection";
import facebook from "../../assets/images/facebook.png";

const Service = () => {
  return (
    <div className="service-container">
      {/* Section 1: Introduction */}
      <div className="service-intro-section">
        <section className="service-intro">
          <h1>
            The <span className="highlight">Best Services</span> You Can Get
            Anywhere
          </h1>
          <p>
            Boost your online presence effortlessly with our premium SMM panel
            services. From enhancing social media engagement to delivering
            real-time results, we provide tailored solutions for Facebook,
            Instagram, YouTube, and more. Experience top-quality service with
            secure transactions, competitive pricing, and 24/7 customer support.
            Elevate your brand and stay ahead in the digital space!.
          </p>
          <div className="buttons">
            <button className="pricing-btn">Pricing</button>
            <button className="register-btn">Register</button>
          </div>
        </section>

        <div className="service-image">
          <img src={trendyReach} alt="Best Service" />
        </div>
      </div>
      {/* Section 2: Comparison Section */}
      <section className="comparison-section">
        <div className="comparison-text">
          <h2>
            What <span className="highlight">Makes Us Different</span> From
            Others?
          </h2>
          <p>
            At SMM Seva, we prioritize quality, reliability, and customer
            satisfaction. Unlike others, we provide:
            <br />~ Top-Tier Service Quality: Authentic engagement and
            measurable results, not bots or fake accounts. <br />~ Unmatched
            Support: 24/7 dedicated customer assistance to resolve queries
            promptly. <br />~ Exclusive Offers: Unique bonuses and flexible
            packages tailored to your needs. <br />~ Secure Transactions:
            Advanced payment protection and data privacy for a seamless
            experience
          </p>
        </div>
        <div className="comparison-table-wrapper">
          <table className="comparison-table">
            <thead>
              <tr>
                <th>Feature</th>
                <th>SMMSeva</th>
                <th>Other Panels</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>24x7 Support</td>
                <td>✔</td>
                <td>✖</td>
              </tr>
              <tr>
                <td>Good Quality Services</td>
                <td>✔</td>
                <td>✖</td>
              </tr>
              <tr>
                <td>Instant Delivery</td>
                <td>✔</td>
                <td>✖</td>
              </tr>
              <tr>
                <td>WhatsApp Services</td>
                <td>✔</td>
                <td>✖</td>
              </tr>
              <tr>
                <td>Bulk Order Support</td>
                <td>✔</td>
                <td>✖</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
      {/* Section 3: Facebook Services */}
      <section className="facebook-services">
        <div className="facebook-services-text">
          <h2>
            Best <span className="highlight">Facebook </span>Services
          </h2>
          <p>
            Boost your page visibility with authentic likes, shares, and
            followers to grow your online presence effortlessly.
          </p>
          <div className="button-type-text">
            <p>Facebook Likes</p>
            <p>Facebook Comments</p>
            <p>Facebook Views</p>
            <p>Facebook Story Views</p>
          </div>
          <button className="explore-our-services">Explore Our Services</button>
        </div>

        <div className="facebook-services-image">
          <img src={facebook} alt="facebook Services" />
        </div>
      </section>

      {/* Section 3: Instagram Services */}
      <section className="instagram-services">
        <div className="instagram-services-text">
          <h2>
            Best <span className="highlight">Instagram </span>Services
          </h2>
          <p>
            Achieve stellar growth with organic followers, story views, and post
            engagement for an influential Insta profile.
          </p>
          <div className="button-type-text">
            <p>Instagram Likes</p>
            <p>Instagram Comments</p>
            <p>Instagram Views</p>
            <p>Instagram Story Views</p>
          </div>
          <button className="explore-our-services">Explore Our Services</button>
        </div>

        <div className="instagram-services-image">
          <img src={instagram} alt="Instagram Services" />
        </div>
      </section>

      <section className="thread-services">
        {/* Text Content */}
        <div className="thread-services-text">
          <h2>
            Best <span className="highlight">Thread</span> Services
          </h2>
          <p>
            Expand your reach and visibility with real engagement on Threads,
            driving meaningful conversations and growth.
          </p>
          <div className="button-type-text">
            <p>Thread Reshares</p>
            <p>Thread Comments</p>
            <p>Thread Views</p>
          </div>
          <button className="explore-our-services">Explore Our Services</button>
        </div>

        {/* Image Content */}
        <div className="bestThreads-image">
          <img src={bestThreads} alt="Best Threads Services" />
        </div>
      </section>
      <section className="spotify-services">
        {/* Text Content */}
        <div className="spotify-text">
          <h2>
            Best <span className="highlight">Spotify</span> Services
          </h2>
          <p>
            Amplify your music with increased plays, followers, and playlist
            additions to get noticed on Spotify.
          </p>
          <div className="button-type-text">
            <p>Spotify Likes</p>
            <p>Spotify Views</p>
            <p>Spotify Shares</p>
            <p>Spotify Saves</p>
          </div>
          <button className="explore-our-services">Explore Our Services</button>
        </div>

        {/* Image Content */}
        <div className="spotify-image">
          <img src={spotify} alt="Spotify Services" />
        </div>
      </section>

      <section className="x-services">
        {/* Text Content */}
        <div className="x-text">
          <h2>
            Best <span className="highlight">X(Twitter)</span> Services
          </h2>
          <p>
            Enhance your tweets' reach and engagement with real followers,
            retweets, and likes tailored for impactful growth.
          </p>
          <div className="button-type-text">
            <p>X(Twitter) Likes</p>
            <p>X(Twitter) Reshares</p>
            <p>X(Twitter) Views</p>
          </div>
          <button className="explore-our-services">Explore Our Services</button>
        </div>

        {/* Image Content */}
        <div className="x-image">
          <img src={x} alt="X(Twitter) Services" />
        </div>
      </section>
    </div>
  );
};

export default Service;
