import React from "react";
import "../../assets/styles/Services/serviceSection.css";

const ServiceSection = () => {
  const services = [
    {
      id: "101",
      price: "$0.024",
      title:
        "♔ Instagram Non Drop Followers - [ 100k/day ] [ Lifetime Refill ]",
      details: [
        "⏱️| Start Time - Instant",
        "⚡| Avg. Speed - 50k-100k/day",
        "♻️| Guarantee - Yes ( Lifetime )",
        "🚫| Cancellation - Yes ( Allowed )",
        "💦| Drop Ratio - No Drop",
      ],
    },
    {
      id: "1015",
      price: "$23.5125",
      title: "♔ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 Telegram 𝗧𝗼𝗽 𝗥𝗮𝗻𝗸𝗶𝗻𝗴 Members - [ 𝟯𝟬𝗱𝗮𝘆𝘀 𝗡𝗼𝗻 𝗗𝗿𝗼𝗽 ]",
      details: [
        "⭐ Best for Channel / Group Ranking ⭐",
        "⏱️ | Start Time : Instant",
        "⚡ | Est. Speed : 20k-30k/day",
        "♻️ | Guarantee : Yes ( 30days )",
        "🚷 | Cancel Req : Yes ( Allowed )",
      ],
    },
    {
      id: "1245",
      price: "$85.00",
      title: "♔ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 Telegram 𝗧𝗼𝗽 𝗥𝗮𝗻𝗸𝗶𝗻𝗴 Members - [ 𝟭𝟴𝟬𝗱𝗮𝘆𝘀 𝗡𝗼𝗻 𝗗𝗿𝗼𝗽 ]",
      details: [
        "⭐ Best for Channel / Group Ranking ⭐",
        "⏱️ | Start Time : 0-1hrs",
        "⚡ | Est. Speed : 15k-20k/day",
        "♻️ | Guarantee : Yes ( 180days )",
        "🚷 | Cancel Req : Yes ( Allowed )",
      ],
    },
    {
      id: "1905",
      price: "$0.78",
      title: "♔ YouTube Video Views - [ 1k/day ] [ External Source ] Instant",
      details: [
        "⏱️ | Start Time : Instant",
        "⚡ | Est. Speed : 1k-2k/day",
        "💦 | Est. Drop : Non Drop Service",
        "♻️ | Guarantee : Yes ( Lifetime )",
        "🚷 | Cancel Req : Yes ( Allowed )",
      ],
    },
    {
      id: "217",
      price: "$0.3329",
      title:
        "♔ Facebook Page Followers - [ R30 ] [ All Pages ] [ 80k/day ] Instant",
      details: [
        "⏱️ | Start Time : Instant - 24hrs",
        "⚡️ | Est. Speed : 80k-100k/day",
        "♻️ | Guarantee : Yes ( 30days )",
        "🚷 | Cancel Req : Allowed",
        "💦 | Est. Drops : Non Drop",
      ],
    },
    {
      id: "790",
      price: "$1.3282",
      title:
        "♔ Twitter (X) Bot Followers - [ 5k/day ] [ No Refill ] [ 10% Drop ] 0-24hrs",
      details: [
        "⏱️ | Start Time : 0-24hrs",
        "⚡️ | Est. Speed : 5k/day",
        "♻️ | Guarantee : No Refill",
        "💦 | Est. Drops : 10% Drop",
        "🚷 | Cancel Req : Not Allowed",
      ],
    },
  ];

  return (
    <section className="services-section">
      <div className="container">
        <div className="secheadingserv">
          <h2>
            All Our <span>Top Selling</span> Services
          </h2>
          <p>
            At SMM Seva, we deliver authentic engagement, 24/7 support, and
            secure transactions, setting us apart with unmatched quality and
            exclusive offers tailored to your needs.
          </p>
        </div>
        <div className="row">
          {services.map((service) => (
            <div className="col-md-4" key={service.id}>
              <div
                className="tsservcard"
                onClick={() =>
                  (window.location.href = `/?select_service_id=${service.id}`)
                }
              >
                <div className="headtscard">
                  <span className="subid">{service.id}</span>
                  <h2>{service.price}</h2>
                </div>
                <p className="headingservts">{service.title}</p>
                <p>
                  {service.details.map((detail, index) => (
                    <span key={index}>
                      {detail}
                      <br />
                    </span>
                  ))}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServiceSection;
