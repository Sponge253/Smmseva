import React from "react";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import "../../assets/styles/Homepage/carouselSection.css";
import fb from "../../assets/images/fb.png";
import insta from "../../assets/images/insta.png";
import yt from "../../assets/images/yt.png";
import x from "../../assets/images/x.png";

const CarouselSection = () => {
  const responsive = {
    desktop: { breakpoint: { max: 3000, min: 1024 }, items: 3 },
    tablet: { breakpoint: { max: 1024, min: 464 }, items: 2 },
    mobile: { breakpoint: { max: 625, min: 0 }, items: 1 },
  };

  const carouselItems = [
    {
      img: fb,
      platform: "Facebook",
      className: "carousel-item",
    },
    {
      img: yt,
      platform: "YouTube",
      className: "carousel-item2",
    },
    {
      img: insta,
      platform: "Instagram",
      className: "carousel-item3",
    },
    // {
    //   img: x,
    //   platform: "Twitter",
    //   className: "carousel-item4",
    // },
  ];

  return (
    <div className="carousel-section">
      <h1 className="text-center px-2">
        Where Quality Meets<span className="highlight"> Your Budget</span>
      </h1>
      <Carousel
        additionalTransfrom={0}
        // autoPlay
        // autoPlaySpeed={1500}
        arrows={false}
        centerMode={false}
        draggable={true}
        infinite={true}
        keyBoardControl
        minimumTouchDrag={80}
        responsive={responsive}
        slidesToSlide={1}
        slidesToShow={3}
        swipeable
        className="carousel-container"
        // Key changes are here:
        removeArrowOnDeviceType={["tablet", "mobile", "desktop"]}
        showDots={false}
        deviceType="desktop"
      >
        {carouselItems.map((item, index) => (
          <div key={index} className={item.className}>
            <img src={item.img} alt={`${item.platform} logo`} />
            <div>
              <h4>{item.platform}</h4>
              <p>Services</p>
            </div>
            <div>
              <h4>Starting From</h4>
              <p>$6.00</p>
            </div>
          </div>
        ))}
      </Carousel>
    </div>
  );
};

export default CarouselSection;
