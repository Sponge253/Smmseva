import React, { useState } from "react";
import "../../assets/styles/Homepage/faq.css";

const FAQs = () => {
  // State to track the active question
  const [activeIndex, setActiveIndex] = useState(0);

  // Toggle function to handle opening/closing FAQ items
  const toggleQuestion = (index) => {
    if (activeIndex === index) {
      // Close the currently active question
      setActiveIndex(null);
    } else {
      // Open the selected question
      setActiveIndex(index);
    }
  };

  const faqData = [
    {
      question: "What services do you provide for YouTube?",
      answer:
        "We offer services such as increasing subscribers, boosting views, enhancing video likes, and providing real-time engagement analytics to help grow your YouTube channel effectively.",
    },
    {
      question: "Can you help increase engagement on Facebook?",
      answer:
        "Yes, we provide services like increasing page likes, post engagement (likes, comments, shares), and targeted advertising to reach the right audience for your Facebook page.",
    },
    {
      question: "Are the subscribers and followers real?",
      answer:
        "We provide real and high-quality subscribers and followers. Our focus is on genuine engagement, ensuring that your social media growth looks organic and credible.",
    },
    {
      question: "How long does it take to see results?",
      answer:
        "Results depend on the type of service. For YouTube views and Facebook engagement, results can often be seen within 24–48 hours. For larger campaigns, it may take up to a few days.",
    },
  ];

  return (
    <div>
      <section className="section-faq">
        <div className="container">
          <div className="row justify-content-center text-center">
            <div className="col-md-8 mb-4">
              <h1 className="text-center ">
                Your <span style={{ color: "#00eeff" }}> Top Questions</span>{" "}
                Answered
              </h1>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12">
              <div className="questions">
                {faqData.map((faq, index) => (
                  <div
                    key={index}
                    className={`single-question ${
                      activeIndex === index ? "active" : ""
                    }`}
                  >
                    <div
                      onClick={() => toggleQuestion(index)}
                      style={{ cursor: "pointer" }}
                    >
                      <h3>{faq.question}</h3>
                      <i
                        className={`fas fa-angle-down ${
                          activeIndex === index ? "rotate" : ""
                        }`}
                      ></i>
                    </div>
                    <p
                      className="answer"
                      style={{
                        display: activeIndex === index ? "block" : "none",
                        paddingLeft: "10px",
                      }}
                    >
                      {faq.answer}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQs;
