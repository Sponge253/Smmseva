import React from "react";
import "../../assets/styles/Homepage/cards.css";
import { GoArrowDownRight } from "react-icons/go";
import { HiOutlineTrophy } from "react-icons/hi2";
import { IoWalletOutline } from "react-icons/io5";
import { BsCartCheck } from "react-icons/bs";
import { TbUserPlus } from "react-icons/tb";

const CardsSection = () => {
  return (
    <div>
      <h2 style={{ fontSize: "40px" }}>
        How Does it <span style={{ color: "#00eeff" }}>Work</span> ?
      </h2>
      <div className="d-flex flex-wrap justify-content-center gap-4 my-3">
        <div className="card" id="card1">
          <div className="card-icon">
            <TbUserPlus />
          </div>
          <div className="card-content">
            <div className="card-title">
              <div className="numbering">
                <span>01</span>
                <GoArrowDownRight size={30} />
              </div>
              <h4>Registration</h4>
            </div>
            <p className="card-details">
              Sign up with us and create your personalized account. Get instant
              access to our platform with just a few simple steps.
            </p>
          </div>
        </div>
        <div className="card" id="card2">
          <div className="card-icon">
            <IoWalletOutline />
          </div>
          <div className="card-content">
            <div className="card-title">
              <div className="numbering">
                <span>02</span>
                <GoArrowDownRight size={30} />
              </div>
              <h4>Add Funds</h4>
            </div>
            <p className="card-details">
              Securely add funds to your account using multiple payment options.
              Enjoy complete transparency and flexibility.
            </p>
          </div>
        </div>
        <div className="card" id="card3">
          <div className="card-icon">
            <BsCartCheck />
          </div>
          <div className="card-content">
            <div className="card-title">
              <div className="numbering">
                <span>03</span>
                <GoArrowDownRight size={30} />
              </div>
              <h4>Select the Service</h4>
            </div>
            <p className="card-details">
              Browse through a wide range of services tailored to meet your
              social media needs. Choose what fits your goals best.
            </p>
          </div>
        </div>
        <div className="card" id="card4">
          <div className="card-icon">
            <HiOutlineTrophy />
          </div>
          <div className="card-content">
            <div className="card-title">
              <div className="numbering">
                <span>04</span>
                <GoArrowDownRight size={30} />
              </div>
              <h4>Place Order & Monitor</h4>
            </div>
            <p className="card-details">
              Place your order with ease and track its progress in real-time.
              Experience hassle-free delivery of outstanding results.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardsSection;
