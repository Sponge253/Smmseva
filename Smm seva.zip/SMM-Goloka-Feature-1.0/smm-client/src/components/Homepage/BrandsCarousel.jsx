import React from "react";
import "../../assets/styles/Homepage/brandCarousel.css";

import fb from "../../assets/images/fb.png";
import insta from "../../assets/images/insta.png";
import yt from "../../assets/images/yt.png";
import linkedin from "../../assets/images/in.png";

const BrandsCarousel = () => {
  const logos = [
    { src: fb, name: "Facebook" },
    { src: insta, name: "Instagram" },
    { src: linkedin, name: "LinkedIn" },
    { src: yt, name: "YouTube" },
  ];

  const repeatedLogos = new Array(24).fill(null).flatMap(() => logos);

  return (
    <div className="mt-3">
      <h1 className="text-center py-3 ">
        We Are <span style={{ color: "#00eeff" }}> Recognized</span> By These
        Companies
      </h1>
      <div className="brand-logos">
        {[...Array(2)].map((_, index) => (
          <div className="brand-logo_items" key={index}>
            {repeatedLogos.map((logo, i) => (
              <div
                className="brand-logo_container d-flex align-items-center justify-content-center"
                key={i}
              >
                <img src={logo.src} alt={`Logo ${i}`} className="brand-logo" />
                <span className="brand-logo_name">{logo.name}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BrandsCarousel;
