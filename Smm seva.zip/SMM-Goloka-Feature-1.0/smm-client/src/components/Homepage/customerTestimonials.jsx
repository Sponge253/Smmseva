import React from "react";
import "../../assets/styles/Homepage/customer.css";

const CustomerTestimonials = () => {
  const testimonials = [
    {
      message:
        "SMM Seva is the best SMM Panel for increasing social media growth and online visibility. After connecting to SMM Seva we have really seen the result. I thank SMM Seva for making positive impact on my channel.",
      name: "Jennifer Smith",
      img: "https://i.imgur.com/noO3Yuz.png",
      title: "Marketing Director",
      color: "#00eeff",
    },
    {
      message:
        "I had a great experience with SMM Seva. Their services helped my business gain more followers and engagement. It’s been an amazing journey, and I highly recommend their services!",
      name: "John Doe",
      img: "https://i.imgur.com/noO3Yuz.png",
      title: "Business Owner",
      color: "#00eeff",
    },
    {
      message:
        "SMM Seva’s services are incredible! The team is professional and quick to respond. I noticed a significant increase in engagement on my social media platforms after using their services.",
      name: "Sarah Lee",
      title: "Content Creator",
      img: "https://i.imgur.com/noO3Yuz.png",
      color: "#00eeff",
    },
    {
      message:
        "SMM Seva really helped my e-commerce business grow. The results were immediate, and the team provided excellent support throughout the process.",
      name: "Mark Johnson",
      title: "E-commerce Owner",
      img: "https://i.imgur.com/noO3Yuz.png",
      color: "#00eeff",
    },
    {
      message:
        "I have been using SMM Seva for a few months now, and my social media presence has skyrocketed. Their services are top-notch, and I highly recommend them to anyone looking to boost their online visibility.",
      name: "Emily Davis",
      title: "Social Media Manager",
      img: "https://i.imgur.com/noO3Yuz.png",
      color: "#00eeff",
    },
    {
      message:
        "The SMM Seva panel has been a game-changer for my business. The results speak for themselves, and the customer support is fantastic. Highly recommended for anyone looking to boost their social media presence.",
      name: "Michael Brown",
      title: "Entrepreneur",
      img: "https://i.imgur.com/noO3Yuz.png",
      color: "#00eeff",
    },
  ];

  return (
    <div>
      <h1 className="text-center">
        See what our
        <span style={{ color: "#00eeff" }}> 56k+ Customers </span> have to say
        about us.
      </h1>
      <div className="customer-card-container">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="customer-card">
            <p>{testimonial.message}</p>
            <div className="d-flex align-items-center gap-4">
              <div className="customer-icon">
                <img src={testimonial.img} />
              </div>
              <h6>
                <span style={{ color: testimonial.color }}>
                  {testimonial.name}
                </span>
                <br />
                {testimonial.title}
              </h6>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomerTestimonials;
