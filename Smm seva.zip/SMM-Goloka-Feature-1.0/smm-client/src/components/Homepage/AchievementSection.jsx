import React from "react";
import "../../assets/styles/Homepage/achievement.css";
import { FaRocket } from "react-icons/fa";

const AchievementSection = () => {
  return (
    <section className="achievement-section">
      <div className="achievement-text">
        <button>
          <FaRocket style={{ color: "#00eeff" }} /> Beyond Boundaries
        </button>
        <h1>
          Honoring Our
          <br /> <span className="highlight">Achievements</span>
        </h1>
        <p>
          <span style={{ color: "#00eeff" }}>SMM Seva</span> boasts a thriving
          community of over 55,000+ active users who have collectively invested
          $1.5 Million in our platform. With a diverse offering of 1500+
          services, we have successfully fulfilled 2M+ orders, solidifying our
          position as a trusted leader in the industry.
        </p>
      </div>

      <div className="achievement-cards">
        <div className="achievement-card">
          <h4>69176</h4>
          <p>Happy Users</p>
        </div>
        <div className="achievement-card">
          <h4>$1.5 Million</h4>
          <p>Invested By Users</p>
        </div>
        <div className="achievement-card">
          <h4>3345312</h4>
          <p>Successful Orders</p>
        </div>
        <div className="achievement-card">
          <h4>5011</h4>
          <p>Active Services</p>
        </div>
      </div>
    </section>
  );
};

export default AchievementSection;
