import React, { useState } from "react";
import "../../assets/styles/Homepage/signin.css";
import { Link, useNavigate } from "react-router-dom";

const SignInSection = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSignIn = () => {
    // Dummy credentials
    const validUsername = "Smmseva108";
    const validPassword = "Smmseva@1080";

    if (username === validUsername && password === validPassword) {
      window.alert("Sign-in successful!");

      navigate("/plans");
    } else {
      window.alert("Invalid credentials. Please try again.");
    }
  };

  return (
    <div className="signin-container text-center d-flex flex-column align-items-center justify-content-center gap-4">
      <button>Your Growth Partner</button>
      <h1>
        Transform Your Online Presence with{" "}
        <span style={{ color: "#00eeff", fontSize: "50px" }}>SMMSeva!</span>
      </h1>
      <p>
        Unlock the full potential of your social media with cutting-edge tools,
        unbeatable prices, and expert support. <br />
        Build, grow, and thrive in the digital world with ease.
      </p>
      <div className="d-flex gap-3">
        <button id="active" onClick={() => navigate("/register")}>
          Join Now
        </button>
        <button onClick={() => navigate("/plans")}>Explore Plans</button>
      </div>
      <div className="signin-form ">
        <div className="signin-inputs">
          <div
            className="input-box"
            style={{ marginBottom: "0px", width: "100%" }}
          >
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <label>Username</label>
          </div>
          <div
            className="input-box"
            style={{ marginBottom: "0px", width: "100%" }}
          >
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <label>Password</label>
          </div>
        </div>
        <button
          style={{ width: "100%", borderRadius: "5px", padding: "8px" }}
          id="active"
          onClick={handleSignIn}
        >
          Sign In
        </button>
        <p>
          Don't have an account?{" "}
          <Link
            style={{
              color: "#00eeff",
              textDecoration: "underline",
            }}
            to={"/register"}
          >
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default SignInSection;
