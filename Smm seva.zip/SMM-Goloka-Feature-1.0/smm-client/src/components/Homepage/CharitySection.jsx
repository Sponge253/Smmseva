import React from "react";
import "../../assets/styles/Homepage/achievement.css";
import { FaHandHoldingUsd } from "react-icons/fa";
import img from "../../assets/images/3d-modified.png";

const CharitySection = () => {
  return (
    <section className="achievement-section my-5">
      <div className="achievement-text">
        <h1>
          Making an
          <br /> <span className="highlight">Impact Together</span>
        </h1>
        <p>
          <span style={{ color: "#00eeff" }}>SMM Seva</span> believe in creating
          not just business growth but also positive social change. That’s why
          [X]% of the revenue from our Social Media Marketing Panel goes
          directly to charitable causes. <br />
          Together, we’re helping make a difference—one campaign at a time.
        </p>
        <p>
          Your support empowers us to contribute to social causes. Thank you for
          being part of our mission to give back and spread positivity in the
          world."
        </p>
        <button>
          <FaHandHoldingUsd size={20} style={{ color: "#00eeff" }} /> Learn More
          About Our Charity Initiatives
        </button>
      </div>

      <div className="charity-image">
        <img src={img} />
      </div>
    </section>
  );
};

export default CharitySection;
