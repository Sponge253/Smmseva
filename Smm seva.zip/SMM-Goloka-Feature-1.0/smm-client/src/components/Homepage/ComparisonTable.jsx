import React from "react";
import "../../assets/styles/Homepage/ComparisonTable.css";
import { FaRegCheckCircle, FaRegTimesCircle } from "react-icons/fa";

const ComparisonTable = () => {
  const data = [
    {
      feature: "Service Quality",
      otherSites: "Inconsistent quality, often fake or bots",
      smmSeva: "High-quality services, real engagement",
    },
    {
      feature: "Customer Support",
      otherSites: "Limited support, delayed responses",
      smmSeva: "24/7 responsive support",
    },
    {
      feature: "User Interface",
      otherSites: "Cluttered interface, confusing navigation",
      smmSeva: "Intuitive and user-friendly platform",
    },
    {
      feature: "Service Customization",
      otherSites: "Limited customization, fixed packages",
      smmSeva: "Flexible options, tailored to your needs",
    },
    {
      feature: "Order Tracking",
      otherSites: "Lack of transparency, unclear tracking",
      smmSeva: "Real-time progress updates",
    },
    {
      feature: "Payment Security",
      otherSites: "Concerns about payment safety and privacy",
      smmSeva: "Secure transactions and data protection",
    },
    {
      feature: "User Satisfaction",
      otherSites: "Mixed reviews, dissatisfaction common",
      smmSeva: "High customer satisfaction rates",
    },
  ];

  return (
    <div className="my-5">
      <h1 className="text-center py-3">
        Comparative Analysis of Leading{" "}
        <span style={{ color: "#00eeff" }}> SMM Panels</span>
      </h1>
      <div className="comparison-table-container">
        <div className="comparison-table">
          <div className="table-header">
            <div className="column features">Features</div>
            <div className="column other-sites">
              <div style={{ fontSize: "25px" }}>Other Sites</div>
              <div className="success-rate">Success Rate 49.99%</div>
              <div className="tagline">No Exclusiveness</div>
            </div>
            <div className="column smm-birla">
              <div style={{ fontSize: "25px" }}>SMM Seva</div>
              <div className="success-rate">Success Rate 99.99%</div>
              <div className="tagline">Exclusive Offers & Bonuses</div>
            </div>
          </div>
          <div className="table-body">
            {data.map((row, index) => (
              <div key={index} className="table-row">
                <div className="column features">{row.feature}</div>
                <div className="column other-sites">
                  <FaRegTimesCircle size={20} style={{ color: "red" }} />{" "}
                  {row.otherSites}
                </div>
                <div className="column smm-birla">
                  <FaRegCheckCircle size={20} style={{ color: "green" }} />{" "}
                  {row.smmSeva}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComparisonTable;
