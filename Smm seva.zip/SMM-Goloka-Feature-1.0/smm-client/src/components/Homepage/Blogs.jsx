import React from "react";
import "../../assets/styles/Homepage/blogs.css";
import { IoIosArrowRoundForward } from "react-icons/io";


const Blogs = () => {
  // Dummy Blog Data
  const mainBlog = {
    title: "What is SMM? How it Works",
    description:
      "Social Media Marketing (SMM) refers to the use of social media platforms to promote a product, service, or brand...",
    image: "https://cdn.mypanel.link/7de874/kzjia4k8nygbrwij.jpg",
  };

  const subBlogs = [
    {
      title: "The Importance of SMM for Small Businesses",
      description:
        "Discover how Social Media Marketing can help small businesses grow their reach and customer base...",
      image:
        "https://miro.medium.com/v2/resize:fit:1080/1*2TTR4xMUU_ZpncFZaRoaMg.png",
    },
    {
      title: "How to Choose the Right SMM Panel for Your Needs",
      description:
        "Finding the perfect SMM panel can save time and boost your online presence effectively...",
      image:
        "https://autonomenp.com/wp-content/uploads/2022/05/How-SMM-works-768x340.jpg",
    },
    {
      title: "Top Trends in Social Media Marketing for 2024",
      description:
        "Stay ahead of the curve with these emerging trends in the world of social media marketing...",
      image: "https://cdn.mypanel.link/7de874/7qkitgxjie5uehbi.png",
    },
  ];

  return (
    <div style={{ marginBottom: "80px" }}>
      <h1 className="text-center ">
        Stay Updated with<span style={{ color: "#00eeff" }}> Our Blogs</span>
      </h1>
      <div className="blogs-section">
        {/* Main Blog */}
        <div className="main-blog">
          <img src={mainBlog.image} alt={mainBlog.title} />
          <h5>{mainBlog.title}</h5>
          <p>{mainBlog.description}</p>
        </div>

        {/* Sub Blogs */}
        <div>
          {subBlogs.map((blog, index) => (
            <div key={index} className="sub-blog">
              <img src={blog.image} alt={blog.title} />
              <div>
                <h5>{blog.title}</h5>
                <p>{blog.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Blogs Button */}
      <div className="blogs-btn d-flex justify-content-center">
        <button >
          Check all blogs <IoIosArrowRoundForward size={20} />
        </button>
      </div>
    </div>
  );
};

export default Blogs;
