import React from "react";
import "../../assets/styles/Homepage/feature.css";
import { MdVerifiedUser } from "react-icons/md";
import { FaRocket } from "react-icons/fa";
import { FaComment } from "react-icons/fa";
import { MdLaptopWindows } from "react-icons/md";

const FeatureSection = () => {
  return (
    <div>
      <h1 className="text-center">
        Unmatched Performance,
        <span style={{ color: "#00eeff" }}> Unrivaled Features</span>
      </h1>
      <div className="features-card-container">
        <div className="feature-card">
          <div className="feature-icon">
            <MdVerifiedUser />
          </div>
          <h4>Trusted SMM Services</h4>
          <p>
            Prioritizing authenticity, we deliver genuine social media
            engagement for a trustworthy platform that exceeds expectations,
            fostering long-term trust and success.
          </p>
        </div>
        <div className="feature-card">
          {" "}
          <div className="feature-icon">
            <FaRocket />
          </div>
          <h4>Instant Light Speed Delivery</h4>
          <p>
            Experience swift, efficient, and reliable SMM services that
            accelerate your online presence, ensuring instant impact and
            surpassing your goals Delivered Right on time.
          </p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">
            <FaComment />
          </div>
          <h4>24X7 Instant Support</h4>
          <p>
            Our dedicated team provides around-the-clock assistance, addressing
            queries and concerns for your seamless experience, making us your
            reliable companion every hour.
          </p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">
            <MdLaptopWindows />
          </div>
          <h4>User Centric UI Design</h4>
          <p>
            Our intuitive digital experience simplifies navigation, creating an
            interface that feels like a seamless extension of your intent,
            ensuring functional and enjoyable interaction.
          </p>
        </div>
      </div>
    </div>
  );
};

export default FeatureSection;
