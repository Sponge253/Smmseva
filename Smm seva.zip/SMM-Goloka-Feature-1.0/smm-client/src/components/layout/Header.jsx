import React, { useState } from "react";
import "../../assets/styles/header.css";
import { Link, useNavigate } from "react-router-dom";
import { SlMenu } from "react-icons/sl";
import { RiCrossLine } from "react-icons/ri";
import { RxCross1 } from "react-icons/rx";

const Header = () => {
  const navigate = useNavigate();
  const [activeButton, setActiveButton] = useState("register");
  return (
    <header className="header">
      <div className="logo">
        <img src="" alt="" />
        <span style={{ cursor: "pointer" }} onClick={() => navigate("/")}>
          SMMSeva
        </span>
      </div>
      <nav className="nav-links">
        <Link to="/terms">
          <i className="icon-terms"></i> Terms
        </Link>

        <div class="dropdown">
          <Link
            className="dropdown-toggle"
            role="button"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <i className="icon-ai "></i> Services
          </Link>

          <ul class="dropdown-menu">
            <li>
              <a class="dropdown-item" href="instagram-services">
                Instagram Services
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="telegram-services">
                Telegram Services
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="/services">
                Services
              </a>
            </li>
          </ul>
        </div>
        <Link to="/blogPage">
          <i className="icon-services"></i> Blogs
        </Link>
      </nav>
      <div className="auth-buttons">
        <Link
          to="/"
          className="login-btn"
          id={activeButton === "login" ? "active" : ""}
          onClick={() => setActiveButton("login")}
        >
          Log In
        </Link>
        <Link
          to="/register"
          className="login-btn"
          id={activeButton === "register" ? "active" : ""}
          onClick={() => setActiveButton("register")}
        >
          Register
        </Link>
      </div>{" "}
      <Link
        className="res-menu-button"
        data-bs-toggle="offcanvas"
        data-bs-target="#offcanvasScrolling"
        aria-controls="offcanvasScrolling"
      >
        <SlMenu size={25} style={{ color: "#fff" }} />
      </Link>
      <div
        class="offcanvas offcanvas-start text-bg-dark"
        data-bs-scroll="true"
        data-bs-backdrop="false"
        tabindex="-1"
        id="offcanvasScrolling"
        aria-labelledby="offcanvasScrollingLabel"
      >
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasScrollingLabel">
            SMMSeva
          </h5>
          <button
            type="button"
            style={{ background: "none", border: "none", color: "#fff" }}
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          >
            <RxCross1 size={25} />
          </button>
        </div>
        <div class="offcanvas-body">
          <nav className="res-nav-links">
            <Link to="/">
              <i className="icon-terms"></i> Home
            </Link>
            <Link to="/terms">
              <i className="icon-terms"></i> Terms
            </Link>
            <Link to="/blogs">
              <i className="icon-ai"></i> Blogs
            </Link>
            <Link href="/services">
              <i className="icon-services"></i> Services
            </Link>
          </nav>
          <div className="res-auth-buttons">
            <Link
              to="/"
              className="login-btn"
              id={activeButton === "login" ? "active" : ""}
              onClick={() => setActiveButton("login")}
            >
              Log In
            </Link>
            <Link
              to="/register"
              className="login-btn"
              id={activeButton === "register" ? "active" : ""}
              onClick={() => setActiveButton("register")}
            >
              Register
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
