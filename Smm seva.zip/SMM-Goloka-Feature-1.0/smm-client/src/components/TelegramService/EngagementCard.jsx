import React from 'react';

const EngagementCard = ({ title, text }) => {
  return (
    <div className="bg-black/60 text-white rounded-lg shadow-lg border border-gray-400 p-6 flex flex-col justify-between h-full transition-all hover:scale-105 hover:shadow-xl duration-300">
      <div>
        <h2 className="text-lg font-semibold text-yellow-400 mb-3">{title}</h2>
        <p className="text-gray-300 text-sm">{text}</p>
      </div>
    </div>
  );
};

const EngagementCardsGrid = () => {
  const cardData = [
    {
      title: "Instant Engagement",
      text: "With our Telegram member panel, you can instantly boost your engagement metrics. Likes, comments, shares – you name it, we've got it covered. Watch your content become the talk of the town in no time."
    },
    {
      title: "Real and Authentic",
      text: "Say goodbye to bots and fake accounts. Our SMM panel delivers genuine interactions with real users. Develop a trustworthy online presence that resonates with your audience."
    },
    {
      title: "Targeted Growth",
      text: "Customize your engagement strategy with precision. Focus on specific demographics, interests, or regions to ensure your content reaches the right people."
    },
    {
      title: "Affordable Packages",
      text: "Our Telegram non-drop member panel believes in quality service that doesn't break the bank. Choose from a range of budget-friendly packages that align with your goals."
    },
    {
      title: "24/7 Support",
      text: "Do you require assistance? Our proficient support team is available 24/7 to guide you through every step of the process."
    },
    {
      title: "Data-Driven Insights",
      text: "Stay informed with detailed analytics that showcases your progress. Track the impact of your campaigns and make informed decisions for future strategies."
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {cardData.map((card, index) => (
          <EngagementCard 
            key={index} 
            title={card.title} 
            text={card.text} 
          />
        ))}
      </div>
    </div>
  );
};

export default EngagementCardsGrid;
