import React, { useState, useEffect, useRef } from 'react';
import '../../assets/styles/AboutUs/automaticInfiniteCarousel.css';

// Inline SVG Icons
const ChevronLeftIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="15 18 9 12 15 6"></polyline>
    </svg>
);

const ChevronRightIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="9 18 15 12 9 6"></polyline>
    </svg>
);

export function AutomaticInfiniteCarousel({ 
    images, 
    interval = 2000,
    slideWidth = '500px',
    slideHeight = '300px'
}) {
    const [currentIndex, setCurrentIndex] = useState(0);
    const carouselRef = useRef(null);

    // Ensure images exist and is an array
    const validImages = Array.isArray(images) ? images : [];
    
    // Create duplicated images for infinite scroll effect
    const displayImages = [
        ...validImages, 
        ...validImages, 
        ...validImages
    ];

    const totalImages = validImages.length;

    // Scroll function
    const scroll = (direction) => {
        if (totalImages === 0) return;

        const newIndex = direction === 'left' 
            ? currentIndex - 1 
            : currentIndex + 1;

        // Handle wrapping
        let finalIndex = newIndex;
        if (newIndex >= totalImages * 2) {
            finalIndex = 0;
        } else if (newIndex < 0) {
            finalIndex = totalImages * 2 - 1;
        }

        setCurrentIndex(finalIndex);
    };

    // Automatic scrolling effect
    useEffect(() => {
        const autoScroll = setInterval(() => {
            scroll('right');
        }, interval);

        return () => clearInterval(autoScroll);
    }, [interval, currentIndex, totalImages]);

    // Prevent errors if no images
    if (totalImages === 0) {
        return <div>No images to display</div>;
    }

    return (
        <div 
            className="carousel-container" 
            style={{ 
                width: slideWidth, 
                height: slideHeight,
                margin: '0 auto'
            }}
        >
            <div 
                ref={carouselRef} 
                className="carousel-track"
                style={{ 
                    transform: `translateX(-${(currentIndex + totalImages) * (100 / displayImages.length)}%)`,
                    width: `${displayImages.length * 100}%`
                }}
            >
                {displayImages.map((src, index) => (
                    <div 
                        key={index} 
                        className="carousel-slide"
                        style={{ 
                            width: `${100 / displayImages.length}%`,
                            height: '100%'
                        }}
                    >
                        <img 
                            src={src} 
                            alt={`Carousel item ${index % totalImages}`} 
                            style={{ 
                                width: '100%',
                                height: '100%',
                                objectFit: 'contain' // Ensures images are equal size and cover the slide
                            }}
                        />
                    </div>
                ))}
            </div>
            <div className="carousel-buttons">
                <button 
                    className="carousel-button carousel-button-left" 
                    onClick={() => scroll('left')}
                >
                    <ChevronLeftIcon />
                </button>
                <button 
                    className="carousel-button carousel-button-right" 
                    onClick={() => scroll('right')}
                >
                    <ChevronRightIcon />
                </button>
            </div>
        </div>
    );
}