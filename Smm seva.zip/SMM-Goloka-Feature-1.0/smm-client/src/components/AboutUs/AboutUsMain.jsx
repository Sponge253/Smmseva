import React from "react";
import '../../assets/styles/AboutUs/aboutUs.css'
import OurGoal from '../../assets/images/OurGoal.webp'
import RealGrowth from '../../assets/images/RealGrowth.png'
import Innovation from '../../assets/images/innovation.webp'
import excellence from '../../assets/images/excellence.webp'
import { AutomaticInfiniteCarousel } from './AutomaticInfiniteCarousel'
import helpingOne from '../../assets/images/helpingOne.jpg'
import helpingTwo from '../../assets/images/helpingTwo.jpg'
import helpingThree from '../../assets/images/helpingThree.jpg'
import helpingFour from '../../assets/images/helpingFour.jpg'
const images = [
    helpingOne,
    helpingTwo,
    helpingThree,
    helpingFour
  ];
  
const AboutUsMain =()=>{
    return(
        <div className="AboutUs-page">
            <div className="hero-section">
                <h1>Who are <span className="highlight">We</span></h1>
                <h3>Grow Your Social Media. <span className="highlight">Change Lives  </span>❤️ .</h3>
                <p>At SMM Seva, we’re not just helping you boost your social media—we’re helping you make an impact. Here’s what makes us different:</p>
                <ul>
                    <li>
                        Unmatched Security: Your privacy is our top priority. We use advanced protection to keep your data safe, so you can focus on growth without worry.
                    </li>
                    <li>
                        Rock-Solid Reliability: Get fast, consistent results—no delays, no downtime. Our platform is built to deliver, every time.
                    </li>
                    <li>
                        Affordable Excellence: We believe in making top-tier social media services accessible to everyone, from creators to small businesses.
                    </li>
                </ul>
                <p>But the real difference? Every service you buy helps someone in need. A portion of each purchase goes toward providing food, education, and essentials to underserved communities.</p>
                <p>With us, you're not just growing your online presence—you’re making the world a little better. Let’s grow together and give back, one step at a time.</p>
                <section className="goal">
                    <div className="goal-text">
                        <h2>
                        Our <span className="highlight">Goal </span>
                        </h2>
                        <p>
                        At SMM Seva, we help individuals, influencers, and businesses grow their social media presence with affordable, reliable solutions. 
                        Whether you want more followers, likes, or views, our platform makes it easy to boost engagement without the hassle. 
                        Designed to support small businesses, content creators, and agencies, we offer automated, seamless services that deliver real results. 
                        Beyond numbers, we focus on building credibility and helping you stand out in a crowded digital world. With us,
                        you’ll gain the social proof you need to attract more attention, grow your brand, and succeed online.
                        </p>
                        </div>

                    <div className="goal-image">
                        <img src={OurGoal} alt="facebook Services" />
                    </div>
                </section>
                <section className="real-growth">
                    <div className="real-growth-text">
                        <h2>
                        Real <span className="highlight"> Growth</span>. Real <span className="highlight">Integrity</span>. Real <span className="highlight">Results</span>.
                        </h2>
                        <p>
                        At SMM Seva, we believe in delivering genuine services backed by ethical practices. We never cut corners—our focus is on providing real, lasting social media growth that you can trust. Your satisfaction is our top priority, and we’re constantly improving to meet your evolving needs.
                        Need help? Our team is dedicated to fast responses and effective problem-solving, ensuring you’re never left waiting. Whether it’s boosting engagement or resolving an issue, we’re here to support you every step of the way. 
                        With us, you’ll get honest results and a partner you can count on.
                        </p>
                        </div>

                    <div className="real-growth-image">
                        <img src={RealGrowth} alt="facebook Services" />
                    </div>
                </section>
                <section className="innovation">
                    <div className="innovation-text">
                        <h2>
                        <span className="highlight">Evolving to Serve You Better :</span> Our Commitment to Innovation
                        </h2>
                        <p>
                        At SMM Seva, we believe in delivering genuine services backed by ethical practices. We never cut corners—our focus is on providing real, lasting social media growth that you can trust. Your satisfaction is our top priority, and we’re constantly improving to meet your evolving needs.
                        Need help? Our team is dedicated to fast responses and effective problem-solving, ensuring you’re never left waiting. Whether it’s boosting engagement or resolving an issue, we’re here to support you every step of the way. 
                        With us, you’ll get honest results and a partner you can count on.
                        </p>
                        </div>

                    <div className="innovation-image">
                        <img src={Innovation} alt="facebook Services" />
                    </div>
                </section>
                <section className="excellence">
                    <div className="excellence-text">
                        <h2>
                        Your Orders, Our Mission:<span className="highlight"> Excellence Delivered Every Time  </span>  
                        
                        </h2>
                        <p>
                        At SMM Seva, every order you place is our top priority. We know how vital timely, reliable service is for your social media marketing success. That’s why our SMM panel is optimized to deliver fast, accurate results you can count on.
                        We’re dedicated to building trust by ensuring a seamless experience and delivering real value for your campaigns. 
                        With every update and service improvement, we strive to help you achieve success effortlessly and efficiently.
                        </p>
                        </div>

                    <div className="excellence-image">
                        <img src={excellence} alt="facebook Services" />
                    </div>
                </section>
            </div>
            <div className="speciality">
                <h1><span className="bold">Our <span className="highlight">Donation</span> helps them to get a <span className="highlight">New Life</span></span></h1>
                <h3><span className="highlight">10%</span> of the profit amout is <span className="highlight">donated to orphanage</span> and <span className="highlight">needy people</span> for <span className="highlight">better tomorrow</span></h3>
                
            </div>
            
            <AutomaticInfiniteCarousel 
                images={images} 
                interval={3000}  // 3 seconds
                slideWidth="80%"
            />
            
            
            
        </div>
    )
}

export default AboutUsMain;