import React from "react";
import "../../assets/styles/Homepage/whyChoose.css";

const WhyChoose = () => {
  return (
    <section className="cards-section">
      <h2 className="section-title">
        Why Choose <span style={{ color: "#00eeff" }}>GoPanel</span>
      </h2>

      <div className="cards-container">
        {/* Main Feature Card */}
        <div className="main-card">
          <div className="main-card-content">
            <h3>Streamlined Social Media Solutions</h3>
            <p>
              Empower your brand with tools tailored for seamless social media
              management. Save time, boost efficiency, and achieve measurable
              results with GoPanel.
            </p>
          </div>
          <div className="main-card-image">
            <img
              src="https://nashvilleroyalthai.com/wp-content/uploads/2022/03/zwJzgLp.png"
              alt="Streamlined Social Media Solutions"
            />
          </div>
        </div>

        {/* Sub Cards Row */}
        <div className="sub-cards-row">
          <div className="card sub-card">
            <h4>Real-Time Analytics</h4>
            <p>
              Track and optimize your campaigns with in-depth analytics updated
              in real-time.
            </p>
            <img src="https://cdn.rentalpanel.com/custom-data/fs2/s9s7jd45zl1ip2hx.png" />
          </div>

          <div className="card sub-card">
            <h4>Flexible Pricing Plans</h4>
            <p>
              Choose a plan that fits your budget, from startups to large
              agencies.
            </p>
            <img src="https://cdn.mypanel.link/m06oqf/bgzytx7mds4kk1s2.png" />
          </div>

          <div className="card sub-card">
            <h4>Robust SMM Tools</h4>
            <p>
              Schedule posts, manage engagement, and grow your audience all in
              one place.
            </p>
            <img src="https://cdn.mypanel.link/kzxbmv/6nt7tdxrq357p65y.png" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyChoose;
