import React from "react";
import "../../assets/styles/Homepage/infiniteScroller.css";

import fb from "../../assets/images/fb.png";
import insta from "../../assets/images/insta.png";
import yt from "../../assets/images/yt.png";
import linkedin from "../../assets/images/in.png";

const InfiniteScroller = () => {
  const logos = [
    { src: fb, name: "Facebook" },
    { src: insta, name: "Instagram" },
    { src: linkedin, name: "LinkedIn" },
    { src: yt, name: "YouTube" },
  ];

  const repeatedLogos = new Array(24).fill(null).flatMap(() => logos);

  return (
    <div className="logos">
      {[...Array(2)].map((_, index) => (
        <div className="logo_items" key={index}>
          {repeatedLogos.map((logo, i) => (
            <div
              className="logo_container d-flex align-items-center justify-content-center"
              key={i}
            >
              <img src={logo.src} alt={`Logo ${i}`} className="logo" />
              <span className="logo_name">{logo.name}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default InfiniteScroller;
