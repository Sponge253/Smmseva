import React from "react";
import "../../assets/styles/Homepage/ComparisonTable.css";
import { FaRegCheckCircle, FaRegTimesCircle } from "react-icons/fa";
import { FaCircleCheck } from "react-icons/fa6";

const ComparisonTable = () => {
  return (
    <div className="my-5">
      {" "}
      <h1 className="text-center py-3 ">
        Comparative Analysis of Leading{" "}
        <span style={{ color: "#00eeff" }}> SMM Panels</span>
      </h1>{" "}
      <div className="comparison-table">
        <div className="table-header">
          <div className="column features">Features</div>
          <div className="column other-sites">
            <div style={{ fontSize: "25px" }}>Other Sites</div>
            <div className="success-rate">Success Rate 49.99%</div>
            <div className="tagline">No Exclusiveness</div>
          </div>
          <div className="column smm-birla">
            <div style={{ fontSize: "25px" }}>SMM Seva</div>
            <div className="success-rate">Success Rate 99.99%</div>
            <div className="tagline">Exclusive Offers & Bonuses</div>
          </div>
        </div>
        <div className="table-body">
          {[
            {
              feature: "Service Quality",
              otherSites: "Inconsistent quality, often fake or bots",
              smmBirla: "High-quality services, real engagement",
            },
            {
              feature: "Customer Support",
              otherSites: "Limited support, delayed responses",
              smmBirla: "24/7 responsive support",
            },
            {
              feature: "User Interface",
              otherSites: "Cluttered interface, confusing navigation",
              smmBirla: "Intuitive and user-friendly platform",
            },
            {
              feature: "Service Customization",
              otherSites: "Limited customization, fixed packages",
              smmBirla: "Flexible options, tailored to your needs",
            },
            {
              feature: "Order Tracking",
              otherSites: " Lack of transparency, unclear tracking",
              smmBirla: " Real-time progress updates",
            },
            {
              feature: "Payment Security	",
              otherSites: " Concerns about payment safety and privacy	",
              smmBirla: " Secure transactions and data protection",
            },
            {
              feature: "User Satisfaction	",
              otherSites: " Mixed reviews, dissatisfaction common	",
              smmBirla: " High customer satisfaction rates",
            },
          ].map((row, index) => (
            <div key={index} className="table-row">
              <div className="column features">{row.feature}</div>
              <div className="column other-sites">
                <FaRegTimesCircle size={20} style={{ color: "red" }} />{" "}
                {row.otherSites}
              </div>
              <div className="column smm-birla">
                {" "}
                <FaRegCheckCircle size={20} style={{ color: "green" }} />{" "}
                {row.smmBirla}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ComparisonTable;
