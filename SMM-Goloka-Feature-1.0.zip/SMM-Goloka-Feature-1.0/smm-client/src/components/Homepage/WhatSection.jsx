import React from "react";
import "../../assets/styles/Homepage/Section.css";
import img from "../../assets/images/trGvUGU.png";

const SectionTemplate = () => {
  return (
    <section className="template-section">
      <div className="intro-text">
        <button>PayTM SMMPanel</button>
        <h1>
          What is <span className="highlight">SMMSeva</span>?
        </h1>
        <p>
          SMM Birla is the most prominent and cheapest SMM Panel, offering users
          a brilliant platform to enhance their social media image through
          increased followers, reach, engagement, and credibility on social
          media platforms like{" "}
          <span style={{ color: "#00eeff" }}>
            Facebook, Telegram, Instagram, Twitter, YouTube
          </span>
          , etc. Leave those days behind when you had to wait to get organic
          followers on social media. It’s time to upgrade with technological
          advancements and use the best SMM Panel ever!
        </p>
        <p>
          Motivational or persuasive text to encourage action or interaction.
        </p>
      </div>

      <div className="features-cards">
        <img src={img} />
      </div>
    </section>
  );
};

export default SectionTemplate;
