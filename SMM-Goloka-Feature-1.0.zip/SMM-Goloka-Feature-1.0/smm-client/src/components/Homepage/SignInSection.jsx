import React from "react";
import "../../assets/styles/Homepage/signin.css";
import { Link } from "react-router-dom";

const SignInSection = () => {
  return (
    <div className="signin-container text-center d-flex flex-column align-items-center justify-content-center gap-4">
      <button>Your Growth Partner</button>
      <h1>
        Transform Your Online Presence with{" "}
        <span style={{ color: "#00eeff", fontSize: "50px" }}>GoPanel!</span>
      </h1>
      <p>
        Unlock the full potential of your social media with cutting-edge tools,
        unbeatable prices, and expert support. <br />
        Build, grow, and thrive in the digital world with ease.
      </p>
      <div className="d-flex gap-3">
        <button id="active">Join Now</button>
        <button>Explore Plans</button>
      </div>
      <div className="signin-form ">
        <div className="signin-inputs">
          {" "}
          <div
            className="input-box"
            style={{ marginBottom: "0px", width: "100%" }}
          >
            <input type="email" required />
            <label>Email</label>
          </div>
          <div
            className="input-box"
            style={{ marginBottom: "0px", width: "100%" }}
          >
            <input type="password" required />
            <label>Password</label>
          </div>
        </div>
        <button
          style={{ width: "100%", borderRadius: "5px", padding: "8px" }}
          id="active"
        >
          Sign In
        </button>
        <p>
          Don't have an account?{" "}
          <Link
            style={{
              color: "#00eeff",
              textDecoration: "underline",
            }}
            to={"/register"}
          >
            Sign Up
          </Link>
        </p>
      </div>
    </div>
  );
};

export default SignInSection;
