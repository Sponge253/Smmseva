import React from "react";
import "../../assets/styles/Homepage/blocksSection.css";
const BlockSection = () => {
  return (
    <div className="block-section">
      <div className="block1">
        <div className="block-item1">
          <img src="https://i.imgur.com/bXKrqgs.png" />
          <h3>Here Every Click Feels Right!</h3>
          <p>
            Our easy SMM Panel site leads the market with the best UI and UX.
            Our intuitive interface ensures seamless navigation, while
            thoughtful design promotes user engagement. Beyond functionality, we
            offer an immersive journey, setting the standard for excellence in
            digital experiences. Welcome to a platform where aesthetics meets
            user-centric design, redefining what's possible in UI and UX.
          </p>
        </div>
        <div className="block-item2">
          {" "}
          <img src="https://i.imgur.com/bXKrqgs.png" />
          <h3>Stability Unleashed – SMM Panel Services that Stand Strong!</h3>
          <p>
            We understand the significance of reliability when it comes to the
            services we provide. Our commitment to delivering always-working
            solutions is embedded in the core of our values. We pride ourselves
            on maintaining a robust infrastructure and utilizing cutting-edge
            technology to ensure uninterrupted services. Day or night, rain or
            shine, you can trust that our offerings are steadfast and ready to
            meet your needs. We recognize that dependability is crucial, and our
            team works tirelessly to guarantee that our services are
            consistently operational. Your peace of mind is our priority, and
            our unwavering dedication to reliability is the cornerstone of our
            customers' trust.
          </p>
        </div>
      </div>
      <div className="block2">
        <div className="block-item2">
          {" "}
          <img src="https://i.imgur.com/SO2Ivq7.png" />
          <h3>Where Every Query finds a Swift Solution</h3>
          <p>
            Our commitment to providing the best customer support is unwavering.
            Our relentless focus on your satisfaction makes us stand out from
            the crowd. Our dedicated support team is not just knowledgeable
            about our best SMM Panel services; they are passionate about
            ensuring your seamless experience with us. We pride ourselves on
            being responsive, empathetic, and proactive in addressing your
            needs. Our customer support isn't just a service; it's a promise to
            prioritize your peace of mind and deliver unparalleled assistance
            that exceeds expectations. We stand by our satisfaction promise with
            unwavering support, available 24/7. Our dedicated team is here day
            in and day out.
          </p>
        </div>
        <div className="block-item1">
          {" "}
          <img src="https://i.imgur.com/3Simedr.png" />
          <h3>Your Orders, Our Priority</h3>
          <p>
            Experience the speed and convenience of our fastest and cheapest SMM
            panel services. We understand the value of your time and have
            engineered a delivery system that races against the clock to bring
            your orders to a faster completion rate with unmatched velocity.
            Swift, reliable, and efficient – our commitment to the fastest
            delivery is a testament to our dedication.
          </p>
        </div>
      </div>
    </div>
  );
};

export default BlockSection;
