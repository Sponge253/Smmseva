import React, { useState } from "react";
import "../../assets/styles/header.css";
import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const [activeButton, setActiveButton] = useState("register");
  return (
    <header className="header">
      <div className="logo">
        <img src="" alt="" />
        <span style={{ cursor: "pointer" }} onClick={() => navigate("/")}>
          GoPanel
        </span>
      </div>
      <nav className="nav-links">
        <a href="/terms">
          <i className="icon-terms"></i> Terms
        </a>
        <a href="/ai-tools">
          <i className="icon-ai"></i> AI Tools
        </a>
        <a href="/services">
          <i className="icon-services"></i> Services
        </a>
      </nav>
      <div className="auth-buttons">
        <Link
          to="/"
          className="login-btn"
          id={activeButton === "login" ? "active" : ""}
          onClick={() => setActiveButton("login")}
        >
          Log In
        </Link>
        <Link
          to="/register"
          className="login-btn"
          id={activeButton === "register" ? "active" : ""}
          onClick={() => setActiveButton("register")}
        >
          Register
        </Link>
      </div>
    </header>
  );
};

export default Header;
