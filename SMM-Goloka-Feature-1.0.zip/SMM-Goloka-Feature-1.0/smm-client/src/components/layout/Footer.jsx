import React from "react";
import {
  MDBFooter,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
} from "mdb-react-ui-kit";
import "mdb-react-ui-kit/dist/css/mdb.min.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "../../assets/styles/footer.css";
import { Link } from "react-router-dom";
import { IoDiamondSharp } from "react-icons/io5";
import fb from "../../assets/images/fb.png";
import insta from "../../assets/images/insta.png";
import yt from "../../assets/images/yt.png";
import linkedin from "../../assets/images/in.png";

export default function Footer() {
  return (
    <MDBFooter
      bgColor=""
      className="footer text-center text-lg-start text-muted"
    >
      <section className="">
        <MDBContainer className="footer-contents text-center text-md-start ">
          <MDBRow className="">
            <MDBCol md="3" lg="4" xl="3" className="mx-auto mb-4">
              <h3
                style={{ color: "#00eeff" }}
                className="text-uppercase fw-bold mb-4"
              >
                <IoDiamondSharp /> GoPanel
              </h3>
              <p>
                GoPanel is your trusted partner in Social Media Marketing,
                delivering innovative tools and services to grow your online
                presence.
              </p>
            </MDBCol>

            <MDBCol md="2" lg="2" xl="2" className="mx-auto mb-4">
              <h6 className="text-uppercase fw-bold mb-4">Quick links</h6>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  Home
                </Link>
              </p>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  Terms
                </Link>
              </p>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  Tools
                </Link>
              </p>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  Services
                </Link>
              </p>
            </MDBCol>
            <MDBCol md="3" lg="2" xl="2" className="mx-auto mb-4">
              <h6 className="text-uppercase fw-bold mb-4">Quick links</h6>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  About Us
                </Link>
              </p>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  FAQs
                </Link>
              </p>
              <p>
                <Link id="footer-link" to={"/"} className="text-reset">
                  Privacy Policy
                </Link>
              </p>
            </MDBCol>

            <MDBCol md="4" lg="3" xl="3" className="mx-auto mb-md-0 mb-4">
              <h6 className="text-uppercase fw-bold mb-4">Connect with us</h6>
              <div className="social-links">
                <a href="" className="me-4 text-reset">
                  <img src={fb} style={{ height: "35px", width: "35px" }} />
                </a>
                <a href="" className="me-4 text-reset">
                  <img src={insta} style={{ height: "35px", width: "35px" }} />
                </a>

                <a href="" className="me-4 text-reset">
                  <img src={yt} style={{ height: "35px", width: "35px" }} />
                </a>
                <a href="" className="me-4 text-reset">
                  <img
                    src={linkedin}
                    style={{ height: "35px", width: "35px" }}
                  />
                </a>
              </div>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </section>

      <div
        className="text-center p-4 border-top"
        style={{ backgroundColor: "rgba(0, 0, 0, 0.05)" }}
      >
        GoPanel by{" "}
        <a
          className="text-reset fw-bold"
          target="blank"
          href="https://golokait.com/"
        >
          GolokaIT
        </a>
      </div>
    </MDBFooter>
  );
}
