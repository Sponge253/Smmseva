import React from "react";

const WhyChoose = () => {
  return <div></div>;
};

export default WhyChoose;
