import React from "react";

const ToolsPage = () => {
  return <div></div>;
};

export default ToolsPage;
